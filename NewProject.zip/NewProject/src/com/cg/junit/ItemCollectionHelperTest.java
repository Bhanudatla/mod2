package com.cg.junit;

import static org.junit.Assert.*;
import junit.framework.Assert;

import org.junit.Test;
import org.junit.AfterClass;
import org.junit.BeforeClass;

import com.cg.bean.ItemSchema;
import com.cg.exception.ItemException;
import com.cg.helper.*;
import com.cg.ui.ItemUI;


public class ItemCollectionHelperTest {
	static ItemCollectionHelper collectionhelper;
	static ItemSchema item=null;
	@BeforeClass
	public static void beforeClass()
	{
		collectionhelper=new ItemCollectionHelper();
		item=new ItemSchema(82,"Book",456.8,967);
	}
@AfterClass
public static void afterClass()
{
	collectionhelper=null;
	item=null;
	
}

	@Test
	public void testAddItemDetails() throws ItemException
	{
		collectionhelper.AddItemDetails(item);
		Assert.assertNotNull(collectionhelper.toString());
	}


}
