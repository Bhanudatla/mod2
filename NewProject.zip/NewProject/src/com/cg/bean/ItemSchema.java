package com.cg.bean;

import java.util.Random;

public class ItemSchema {
 public	int ItemId;
public String ItemName;
public double ItemPrice;
public int TransactionId;
public  ItemSchema(int ItemId,String ItemName,double ItemPrice,int TransactionId)
   {
	this.ItemId=ItemId;
	this.ItemName=ItemName;
	this.ItemPrice=ItemPrice;
	this.TransactionId=TransactionId;
    }
 public String toString()  {
		
     return "ItemId:\t" +ItemId+"ItemNAme:\t"+ItemName+"ItemPrice:\t"+ItemPrice+"TransactionId:\t"+TransactionId;
    } 

}
