package com.cg.ui;
 import java.util.Scanner;
 import java.util.Random;
 
import com.cg.bean.ItemSchema;
import com.cg.helper.ItemCollectionHelper;
import com.cg.helper.ItemValidator;
import com.cg.exception.ItemException;
 

public class ItemUI {
	static Scanner scanner=new Scanner(System.in);
	static ItemCollectionHelper collectionhelper=null;
	 
	public static void main(String args[])
	{
	int choice=0;
	//ItemCollectionHelper collectionhelper;
	  collectionhelper =new ItemCollectionHelper();
	 while(true)
	 {
		 System.out.println("1.AddItem");
		 System.out.println("2.TotalCountOfItems");
		 System.out.println("3.DisplayItems");
		 System.out.println("4.FindDuplicateItem");
		 System.out.println("5.RemoveRecord");
		 System.out.println("6.exit");
	choice=scanner.nextInt();
	switch(choice)
	{
	case 1:System.out.println("ADDITEM:");
		AddItem();
	  break;
	case 2:System.out.println("TotalcountOfItems:");
	collectionhelper.TotalCountOfItem();
	break;
	case 3: System.out.println("DisplayITEM:");
	collectionhelper.DisplayItem();
	break;
	case 4:System.out.println("Enter the item id to find specific record:");
	int cc=scanner.nextInt();
	collectionhelper.FindDuplicateItem(cc);
	break;
	case 5: System.out.println("Enter the item id of the record to be removed:");
	int id=scanner.nextInt();
	collectionhelper.RemoveItem(id);
	break;
	default:System.exit(0);
	}
	
	}
	
	}
	public static  void AddItem()
	{

		ItemValidator v=new ItemValidator();
		try{
			
		System.out.println("How many items?");
		int icount=scanner.nextInt();
		while(icount!=0)
		{
			System.out.println("Enter Itemid:");
			String ItemId=scanner.next();
			if(ItemValidator.validateItemId(ItemId))
			{
				System.out.println("Enter ItemName");
				String ItemName=scanner.next();
				if(ItemValidator.validateItemName(ItemName))
				{
					System.out.println("Enter ItemPrice:");
					String ItemPrice=scanner.next();
					if(ItemValidator.validateItemPrice(ItemPrice))
					{
						System.out.println("Enter TransactionId:");
						Random randomGenerator=new Random();
                      int TransactionId=randomGenerator.nextInt(9999);
                      System.out.println(TransactionId);
                       ItemSchema item=new ItemSchema(Integer.parseInt(ItemId),ItemName,Double.parseDouble(ItemPrice),TransactionId);
                       
                    	  collectionhelper.AddItemDetails(item);
                    	  /*collectionhelper.DisplayItem();
                    	  collectionhelper.RemoveItem();
                    	  collectionhelper.FindDuplicateItem();	*/
                    	  icount--;
					}
				}
			}
		
		}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
	}
}
