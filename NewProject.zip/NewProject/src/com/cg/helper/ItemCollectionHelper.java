package com.cg.helper;
import java.util.ArrayList;
import java.util.Iterator;
import com.cg.bean.ItemSchema;


public class ItemCollectionHelper {
	private static ArrayList<ItemSchema>Itemlist=new ArrayList<ItemSchema>();
	static
	{
		ItemSchema i1=new ItemSchema(1,"Camera",60000.5,320);
		ItemSchema i2=new ItemSchema(2,"Smartphone",40000.5,321);
		ItemSchema i3=new ItemSchema(3,"WashingMachine",30000.5,322);
		Itemlist.add(i1);
		Itemlist.add(i2);
		Itemlist.add(i3);
	}
	public void AddItemDetails(ItemSchema Item)
	{
		Itemlist.add(Item);
	}
	
  public void TotalCountOfItem()
  {
	  Iterator<ItemSchema>ItemIt=Itemlist.iterator();
	  ItemSchema tempitem=null;
	  int totalCount=0;
	  while(ItemIt.hasNext())
	  {
		  totalCount++;
		  tempitem=ItemIt.next();
	  }
	  System.out.println("TotalCount of Items:"+totalCount);
  }
  public void DisplayItem()
  {
	  /*Iterator<ItemSchema>ItemIt=Itemlist.iterator();
	  ItemSchema tempitem=null;
	  while(ItemIt.hasNext())
	  {
		  tempitem=ItemIt.next();
		  System.out.println(tempitem);
	  }*/
	  for(Object object:Itemlist)
	  {
		  
		  System.out.println(object);
	  }
  }
  public void FindDuplicateItem(int id)
  {
	  for(Object object:Itemlist)
	  {
		  ItemSchema obj=(ItemSchema)object;
			if(obj.ItemId==id)
			{
				System.out.println(object);
			}
	  }
  }
  public void RemoveItem(int id)
  {
	  Iterator<ItemSchema>ItemIt=Itemlist.iterator();
		while(ItemIt.hasNext())
		{
			ItemSchema obj=(ItemSchema)ItemIt.next();
			if(obj.ItemId==id)
			{
				ItemIt.remove();
			}
  }


  
  }
}