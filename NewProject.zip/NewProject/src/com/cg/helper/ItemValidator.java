package com.cg.helper;
import java.util.regex.Pattern;
import com.cg.exception.ItemException;

public class ItemValidator {
	
	public static boolean validateItemId(String ItemId) throws Exception
	{
		String Idpattern="\\d{1,4}";
		if(Pattern.matches(Idpattern, ItemId))
		{
			return true;
		}
		else
		{
			throw new Exception("Only numbers are allowed");
		}
	}
	public static boolean validateItemName(String ItemName) throws Exception{
		String namePattern="[a-zA-Z]{4,6}";
		if(Pattern.matches(namePattern, ItemName))
		{
			return true;
		}
		else
		{
			throw new Exception("ItemName consists of only characters");
		}
		
	}
	public static boolean validateItemPrice(String ItemPrice) throws Exception
	{
		String pricePattern="[0-9]+([,.][0-9]{1,2})?";
		if(Pattern.matches(pricePattern, ItemPrice))              
		{
			return true;
		}
		else
		{
			throw new Exception("ItemPrice consists of only digits");
		}
		
	}
	

}
